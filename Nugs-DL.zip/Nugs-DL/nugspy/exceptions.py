class AuthenticationError(Exception):
	pass

class IneligibleError(Exception):
	pass